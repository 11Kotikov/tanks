export function makeVisibleAndPickable(mesh, visible,pickable) {
    if (mesh.hasOwnProperty('isVisible'))
        mesh.isVisible = visible;
    if (mesh.hasOwnProperty('isPickable'))
        mesh.isPickable = pickable;
        
    if ('getChildren' in mesh) {
        let children = mesh.getChildren();
        for (let child of children) {
            makeVisibleAndPickable(child, visible, pickable)
        }
    }

}

